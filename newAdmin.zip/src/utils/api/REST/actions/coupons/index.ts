export * from './getCouponsList';
