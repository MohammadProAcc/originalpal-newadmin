export interface Activable {
  active?: boolean
  deactive?: boolean
}
