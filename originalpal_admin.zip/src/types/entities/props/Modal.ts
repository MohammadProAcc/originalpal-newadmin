export interface Modal {
  on?: boolean
  toggle?: any
}
