import { FlattenSimpleInterpolation } from 'styled-components'

export interface Styleable {
  Style?: FlattenSimpleInterpolation
}
