export type MenuType =
  | 'top-site'
  | 'ad'
  | 'bottom-site'
  | 'bottom-site-descriptions'
  | 'bottom-site-descrpitions'
  | 'products-bottom-site-menu'
