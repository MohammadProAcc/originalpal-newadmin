export interface AdsMenuItem {
  title: string
  href: string
}

export interface AdsMenu {
  links: AdsMenuItem[]
}
