export interface Address {
  id: number
  postalcode: string
  city: string
  address: string
  province: string
  user_id: number
  created_at: string
  updated_at: string
}
