export const calcPercentage = (total: number, partial: number) => Math.floor(100 - (partial * 100) / total)
