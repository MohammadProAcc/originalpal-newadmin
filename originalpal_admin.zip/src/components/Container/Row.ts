import styled from 'styled-components'

export const Row = styled.div`
  display: flex;
  margin-left: 3rem;

  margin-bottom: 1rem;
`
