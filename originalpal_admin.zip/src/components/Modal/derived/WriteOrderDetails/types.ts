import { Modal } from 'types'

export interface WriteOrderDetailsProps extends Modal {}
