import styled from 'styled-components'
import { ModalBox as _ModalBox } from 'components/Container/ModalBox'

export const ModalBox = styled(_ModalBox)``
