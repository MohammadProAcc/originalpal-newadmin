export interface InputGroupProps {
  col?: boolean
}
