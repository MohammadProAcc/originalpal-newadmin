import styled from 'styled-components'
import { FlexContainer as _FlexContainer } from 'components/Container/FlexContainer'

export const FlexContainer = styled(_FlexContainer)`
  margin-top: 1rem;
`
