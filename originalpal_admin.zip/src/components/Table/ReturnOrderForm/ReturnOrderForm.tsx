import React from 'react'
import { Column, Row } from '../OrderInvoice'
import { Logo, Table } from './components'

export const ReturnOrderForm: React.FC = () => {
  return (
    <Row>
      <Column>
        <Logo />
      </Column>
    </Row>
  )
}
