import styled from 'styled-components'

export const Logo = styled.img.attrs({ src: '/svg/logo.svg' })``
