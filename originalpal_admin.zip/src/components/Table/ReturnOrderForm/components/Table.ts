import styled from 'styled-components'

export const Table = styled.table``
