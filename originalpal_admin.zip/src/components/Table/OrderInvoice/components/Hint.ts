import styled from 'styled-components'

export const Hint = styled.span`
  margin-bottom: 1rem;

  font-family: IRANSansBold;
  font-weight: 900;
  text-align: right;
`
