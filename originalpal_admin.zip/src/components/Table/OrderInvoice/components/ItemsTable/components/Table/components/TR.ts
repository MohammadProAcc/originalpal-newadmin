import styled from 'styled-components'
import { Colors } from 'styles'

export const TR = styled.tr`
  border: 0.0625rem solid ${Colors.black};
`
