import styled from 'styled-components'

export const ProductImage = styled.img`
  width: 3rem;
  height: 3rem;

  object-fit: cover;
`
