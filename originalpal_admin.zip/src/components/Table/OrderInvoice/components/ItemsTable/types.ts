import { OrderItems } from 'types'

export interface ItemsTableProps {
  items: OrderItems
}
