import styled from 'styled-components'

export const Span = styled.span`
  display: block;
  font-family: IRANSansBold !important;

  text-align: center;
`
