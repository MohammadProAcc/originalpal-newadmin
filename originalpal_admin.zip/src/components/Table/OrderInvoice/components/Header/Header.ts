import styled from 'styled-components'

export const Header = styled.div`
  width: 100%;
  padding: 1rem;
  margin-bottom: 3rem;

  display: flex;
  justify-content: center;
`
