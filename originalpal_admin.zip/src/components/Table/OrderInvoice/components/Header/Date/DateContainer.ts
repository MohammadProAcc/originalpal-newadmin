import styled from 'styled-components'

export const DateContainer = styled.div`
  display: flex;
  flex-direction: column;
`
