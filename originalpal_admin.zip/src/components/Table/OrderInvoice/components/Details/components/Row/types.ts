export interface ColumnProps {
  fullWidth?: boolean
}
