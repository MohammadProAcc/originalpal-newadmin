import styled from 'styled-components'

export const Strong = styled.strong`
  margin-left: 0.25rem;

  font-family: IRANSansBold;
`
