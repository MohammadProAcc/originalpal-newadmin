import { OrderInvoiceDetails } from 'components/PageComponents/Orders/types'
import { IOrder } from 'types'

export interface DescriptionProps {
  order: IOrder
}
