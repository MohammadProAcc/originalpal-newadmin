export type InvoiceMode = 'A4' | 'A5'
