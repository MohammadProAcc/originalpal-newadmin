module.exports = {
  env: {
    API: 'https://api.originalpal.co.uk',
    SRC: 'https://originalpal.com/panel',
    _SRC: 'http://api.originalpal.co.uk/images'
  },
  images: {
    domains: [
      'originalpal.com',
      'api.originalpal.co.uk'
    ]
  }
}
