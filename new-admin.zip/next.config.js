module.exports = {
  env: {
    API: 'https://api.originalpal.co.uk',
    SRC: 'https://originalpal.com/panel'
  },
  images: {
    domains: [
      'originalpal.com',
      'api.originalpal.co.uk'
    ]
  }
}
