import { initialLoginResponseUser } from 'types';

export const userSlice = {
  user: initialLoginResponseUser,
};
