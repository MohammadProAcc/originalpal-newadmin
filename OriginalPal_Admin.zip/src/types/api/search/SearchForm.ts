export interface SearchForm {
  key: string;
  type: '=' | 'contain';
  value: string;
}
